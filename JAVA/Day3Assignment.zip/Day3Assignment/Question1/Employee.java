package com.sonata.day3;

public class Employee {

	int empId;
	String empName;
	double empSal;
	public void display() {}
	public void salCal() {}
}